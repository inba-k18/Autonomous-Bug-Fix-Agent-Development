# Test-Driven Development (TDD) & Pytest Best Practices

## What is Test-Driven Development (TDD)?
TDD is a software development process relying on short development cycles:
1. **Red**: Write a failing test for a desired feature or bug fix.
2. **Green**: Write the minimal code necessary to pass the test.
3. **Refactor**: Clean up the code while ensuring all tests continue to pass.

## Pytest Best Practices
- **Naming Conventions**: Name test files `test_*.py` or `*_test.py`. Name test functions `test_*()`.
- **AAA Pattern (Arrange, Act, Assert)**:
  - **Arrange**: Set up inputs, objects, and preconditions.
  - **Act**: Call the function or method being tested.
  - **Assert**: Verify that outcomes match expectations using explicit `assert` statements.
- **Testing Exceptions**: Use `pytest.raises()` to test that expected exceptions are raised:
  ```python
  import pytest

  def test_zero_division():
      with pytest.raises(ZeroDivisionError):
          calculate_ratio(10, 0)
  ```
- **Parametrization**: Use `@pytest.mark.parametrize` to run tests across multiple input scenarios cleanly.
- **Coverage**: Strive for meaningful code coverage (>80%), testing happy paths, boundary conditions, edge cases, and failure modes.
