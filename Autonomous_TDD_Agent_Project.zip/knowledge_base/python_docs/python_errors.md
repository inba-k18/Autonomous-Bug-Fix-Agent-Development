# Python Common Runtime Errors & Debugging Reference

## 1. ZeroDivisionError
- **Cause**: Occurs when a division `/` or modulo `%` operation attempts to divide a number by zero.
- **Example**: `result = total / count` when `count == 0`.
- **Fix**: Check denominator before division or handle with `try...except ZeroDivisionError`.
  ```python
  if count != 0:
      result = total / count
  else:
      result = 0.0
  ```

## 2. RecursionError & Infinite Loops
- **Cause**: Occurs when maximum recursion depth is exceeded or a `while` loop condition never becomes False and lacks a `break` statement.
- **Example**: `while True: print("running")` without break/return.
- **Fix**: Always define base cases for recursive calls and explicit exit conditions for while loops.

## 3. NameError & UnboundLocalError
- **Cause**: Accessing a variable before it has been defined or assigned in the current scope.
- **Fix**: Initialize variables before reference and double-check variable scoping rules.

## 4. TypeError & AttributeError
- **Cause**: Performing an operation on an incompatible data type or accessing a non-existent attribute/method on an object (e.g. calling `.append()` on a dictionary).
- **Fix**: Add type checks (`isinstance()`), optional chaining, or explicit type casting.

## 5. IndexError & KeyError
- **Cause**: Attempting to access a sequence index out of bounds or accessing a missing key in a dictionary.
- **Fix**: Use dictionary `.get(key, default)` method or check `len(sequence)` prior to indexing.

## 6. SyntaxError & IndentationError
- **Cause**: Invalid Python code structure, missing colons `:`, unclosed parenthesis, or mismatched indentation spaces.
- **Fix**: Inspect line number and preceding lines for missing syntax tokens.
