# Python Security Vulnerabilities & Remediation Guide

## 1. Unsafe Dynamic Code Execution (`eval` / `exec`)
- **Vulnerability**: Using `eval()` or `exec()` on untrusted user input allows arbitrary code execution (ACE), enabling attackers to run system commands, steal credentials, or wipe disk content.
- **Risk Level**: High / Critical.
- **Remediation**: Avoid `eval()` and `exec()`. Use safer alternatives such as `ast.literal_eval()` for evaluating basic Python literals (dicts, lists, tuples, strings, numbers, booleans) or use explicit parsers.

## 2. Hardcoded Secrets & Credentials
- **Vulnerability**: Embedding API keys, passwords, private keys, database credentials, or secret tokens directly in source code files.
- **Risk Level**: High.
- **Remediation**: Extract sensitive credentials into environment variables (`.env`) using `os.getenv()` or `python-dotenv`.

## 3. Insecure Deserialization (`pickle`)
- **Vulnerability**: Unpickling data from untrusted sources can execute arbitrary code during deserialization.
- **Risk Level**: High.
- **Remediation**: Use safer data formats such as JSON (`json.loads()`) or protocol buffers.

## 4. Shell Injection & Subprocess Risks
- **Vulnerability**: Calling `os.system()` or `subprocess.Popen(..., shell=True)` with unformatted string concatenation.
- **Risk Level**: High.
- **Remediation**: Pass command arguments as a list of strings and set `shell=False` in `subprocess.run(["ls", "-l"], shell=False)`.

## 5. Weak Randomness for Cryptography
- **Vulnerability**: Using standard `random` module for generating security tokens, password resets, or cryptokeys.
- **Risk Level**: Medium.
- **Remediation**: Use Python's built-in `secrets` module (`secrets.token_hex(32)`).
