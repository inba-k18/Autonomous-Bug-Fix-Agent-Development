# PEP 8 Style Guide Summary & Best Practices

## Code Layout & Formatting
- **Indentation**: Use 4 spaces per indentation level. Avoid mixing tabs and spaces.
- **Line Length**: Limit all lines to a maximum of 79 characters. For long blocks of text, limit to 72 characters.
- **Blank Lines**: Surround top-level function and class definitions with two blank lines. Method definitions inside a class are surrounded by a single blank line.
- **Imports**: 
  - Imports should usually be on separate lines.
  - Put imports at the top of the file, after any module comments and docstrings.
  - Group imports in order: Standard library imports, Related third-party imports, Local application/library specific imports.

## Naming Conventions
- **Modules**: Short, all-lowercase names (`bug_detector`).
- **Classes**: CapWords (PascalCase) convention (`ASTAnalyzer`, `BugDetector`).
- **Functions & Variables**: Lowercase with words separated by underscores (`detect_bugs`, `user_name`).
- **Constants**: All uppercase letters with underscores (`MAX_RETRY_COUNT`, `DEFAULT_TIMEOUT`).

## Docstrings & Comments
- Write docstrings for all public modules, functions, classes, and methods.
- Follow PEP 257: One-line docstrings should summarize the purpose cleanly. Multi-line docstrings should begin with a summary line followed by a blank line and detailed explanation.
- Keep comments up-to-date when code changes.

## Common Code Smells & Violations
- **Unused Imports**: Importing modules that are never referenced in code.
- **Long Functions**: Functions exceeding 30 lines often violate single-responsibility principle.
- **Duplicate Logic**: Repeating code blocks instead of refactoring into modular functions.
- **Wildcard Imports**: Avoid `from module import *` as it pollutes the global namespace.
