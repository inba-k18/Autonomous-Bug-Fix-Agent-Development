import re
import subprocess
import tempfile
import os
from typing import List, Dict, Any
from utils.logger import logger

class PEP8Checker:
    """
    PEP8 Formatting & Style Checker combining lightweight internal checks
    with optional pylint/flake8 execution if installed.
    """

    def __init__(self, code_content: str):
        self.code_content = code_content
        self.lines = code_content.splitlines()

    def check_pep8(self) -> List[Dict[str, Any]]:
        """Runs static PEP8 rule enforcement."""
        issues = []
        
        # 1. Internal Rule Checks
        for line_no, line in enumerate(self.lines, start=1):
            # Line length check (>79 chars)
            if len(line) > 79:
                issues.append({
                    "type": "Line Too Long",
                    "category": "PEP8 Violation",
                    "severity": "Low",
                    "line": line_no,
                    "message": f"Line length ({len(line)} chars) exceeds PEP8 recommendation of 79 characters.",
                    "snippet": line[:79] + "..."
                })

            # Trailing whitespace check
            if line.rstrip('\r\n') != line.rstrip():
                issues.append({
                    "type": "Trailing Whitespace",
                    "category": "PEP8 Violation",
                    "severity": "Low",
                    "line": line_no,
                    "message": "Line contains trailing whitespace.",
                    "snippet": line.strip()
                })

            # Bare except check
            if re.search(r'except\s*:', line):
                issues.append({
                    "type": "Bare Except Clause",
                    "category": "Bad Practice",
                    "severity": "Medium",
                    "line": line_no,
                    "message": "Do not use bare 'except:'; catch specific exceptions like Exception or ValueError.",
                    "snippet": line.strip()
                })

            # Mixed tabs and spaces
            if '\t' in line and ' ' in line:
                issues.append({
                    "type": "Mixed Tabs & Spaces",
                    "category": "PEP8 Violation",
                    "severity": "Medium",
                    "line": line_no,
                    "message": "Tab and space indentation are mixed in the same line.",
                    "snippet": line.strip()
                })

        # 2. Optional flake8/pylint invocation if available
        external_issues = self._run_flake8()
        issues.extend(external_issues)

        return issues

    def _run_flake8(self) -> List[Dict[str, Any]]:
        """Invokes flake8 executable on temporary file if installed."""
        issues = []
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as tmp:
                tmp.write(self.code_content)
                tmp_path = tmp.name

            cmd = ["flake8", "--max-line-length=79", tmp_path]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
            
            if res.stdout:
                for line in res.stdout.splitlines():
                    parts = line.split(":")
                    if len(parts) >= 4:
                        try:
                            l_no = int(parts[1])
                            code_msg = ":".join(parts[3:]).strip()
                            issues.append({
                                "type": "Flake8 Check",
                                "category": "PEP8 Violation",
                                "severity": "Low",
                                "line": l_no,
                                "message": code_msg,
                                "snippet": self.lines[l_no - 1].strip() if 1 <= l_no <= len(self.lines) else ""
                            })
                        except ValueError:
                            pass
        except Exception:
            # flake8 not available or process failed, fallback gracefully
            pass
        finally:
            if 'tmp_path' in locals() and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass

        return issues
