import re
from typing import List, Dict, Any

class SecurityChecker:
    """
    Regex and Pattern-based Security Checker to detect hardcoded secrets,
    passwords, API keys, and insecure system commands.
    """

    PATTERNS = [
        {
            "type": "Hardcoded Password / Key",
            "category": "Security Vulnerability",
            "severity": "High",
            "regex": r'(?i)(password|passwd|secret|api_key|apikey|token|private_key)\s*=\s*["\'][A-Za-z0-9_!@#$%^&*()-+=]{4,}["\']',
            "message": "Potential hardcoded credential or secret detected. Store sensitive data in environment variables."
        },
        {
            "type": "Insecure Shell Command",
            "category": "Security Vulnerability",
            "severity": "High",
            "regex": r'(os\.system|subprocess\.(call|Popen|run)\(.*shell\s*=\s*True.*\))',
            "message": "Executing shell commands with shell=True or os.system can lead to Command Injection vulnerabilities."
        },
        {
            "type": "Insecure Random Generator",
            "category": "Security Vulnerability",
            "severity": "Medium",
            "regex": r'random\.(random|randint|choice)\(',
            "message": "Standard 'random' module is cryptographically insecure. Use 'secrets' module for security-sensitive tokens."
        }
    ]

    def __init__(self, code_content: str):
        self.code_content = code_content
        self.lines = code_content.splitlines()

    def check_security(self) -> List[Dict[str, Any]]:
        """Scans code line by line against defined security rules."""
        issues = []
        for line_no, line in enumerate(self.lines, start=1):
            line_str = line.strip()
            # Skip pure comment lines
            if line_str.startswith("#"):
                continue

            for pattern in self.PATTERNS:
                if re.search(pattern["regex"], line):
                    issues.append({
                        "type": pattern["type"],
                        "category": pattern["category"],
                        "severity": pattern["severity"],
                        "line": line_no,
                        "message": pattern["message"],
                        "snippet": line_str
                    })

        return issues
