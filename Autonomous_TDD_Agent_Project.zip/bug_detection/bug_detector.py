from typing import List, Dict, Any
from bug_detection.ast_analyzer import ASTAnalyzer
from bug_detection.security_checker import SecurityChecker
from bug_detection.pep8_checker import PEP8Checker
from utils.logger import logger

class BugDetector:
    """
    Main Bug Detection Coordinator that combines AST analysis,
    security scanning, and PEP8 static rule checks into a unified report.
    """

    def __init__(self, code_content: str):
        self.code_content = code_content

    def run_all_checks(self) -> Dict[str, Any]:
        """
        Executes all detection suites and aggregates findings.
        Returns a comprehensive report dictionary.
        """
        all_issues: List[Dict[str, Any]] = []

        # 1. AST Analysis
        ast_analyzer = ASTAnalyzer(self.code_content)
        is_valid_syntax, ast_issues = ast_analyzer.analyze()
        all_issues.extend(ast_issues)

        # If syntax error, return immediately as other checks might fail
        if not is_valid_syntax:
            return self._build_report(all_issues, is_valid_syntax=False)

        # 2. Security Checking
        security_checker = SecurityChecker(self.code_content)
        sec_issues = security_checker.check_security()
        all_issues.extend(sec_issues)

        # 3. PEP8 Style Checking
        pep8_checker = PEP8Checker(self.code_content)
        pep8_issues = pep8_checker.check_pep8()
        all_issues.extend(pep8_issues)

        # Deduplicate issues based on (line, type, message)
        unique_issues = self._deduplicate(all_issues)
        
        # Sort by severity
        severity_order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
        unique_issues.sort(key=lambda x: (severity_order.get(x.get("severity", "Low"), 4), x.get("line", 0)))

        return self._build_report(unique_issues, is_valid_syntax=True)

    def _deduplicate(self, issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen = set()
        deduped = []
        for issue in issues:
            key = (issue.get("line"), issue.get("type"), issue.get("message"))
            if key not in seen:
                seen.add(key)
                deduped.append(issue)
        return deduped

    def _build_report(self, issues: List[Dict[str, Any]], is_valid_syntax: bool) -> Dict[str, Any]:
        severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        category_counts = {}

        for issue in issues:
            sev = issue.get("severity", "Low")
            cat = issue.get("category", "General")
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
            category_counts[cat] = category_counts.get(cat, 0) + 1

        return {
            "is_valid_syntax": is_valid_syntax,
            "total_issues": len(issues),
            "severity_counts": severity_counts,
            "category_counts": category_counts,
            "issues": issues
        }
