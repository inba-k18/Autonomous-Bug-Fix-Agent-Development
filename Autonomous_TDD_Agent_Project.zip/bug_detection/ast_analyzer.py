import ast
from typing import List, Dict, Any, Set
from config import MAX_FUNCTION_LENGTH
from utils.logger import logger

class ASTAnalyzer(ast.NodeVisitor):
    """
    Python AST Static Analyzer to detect code smells, logical errors,
    syntax errors, complexity issues, and structural flaws.
    """

    def __init__(self, code_content: str):
        self.code_content = code_content
        self.lines = code_content.splitlines()
        self.issues: List[Dict[str, Any]] = []
        self.imported_names: Set[Tuple[str, int]] = set() # (name, line_no)
        self.used_names: Set[str] = set()
        self.defined_functions: Set[str] = set()
        self.tree = None

    def analyze(self) -> Tuple[bool, List[Dict[str, Any]]]:
        """
        Parses source code into AST and runs custom visitors.
        Returns tuple of (is_valid_syntax, list_of_issues).
        """
        self.issues.clear()
        try:
            self.tree = ast.parse(self.code_content)
        except SyntaxError as e:
            self.issues.append({
                "type": "Syntax Error",
                "category": "Syntax",
                "severity": "High",
                "line": e.lineno or 1,
                "message": f"Syntax Error: {e.msg}",
                "snippet": self.lines[e.lineno - 1] if e.lineno and e.lineno <= len(self.lines) else ""
            })
            return False, self.issues
        except Exception as e:
            self.issues.append({
                "type": "Parse Error",
                "category": "Syntax",
                "severity": "High",
                "line": 1,
                "message": f"Failed to parse AST: {str(e)}",
                "snippet": ""
            })
            return False, self.issues

        # Visit AST nodes
        self.visit(self.tree)
        self._check_unused_imports()

        return True, self.issues

    def visit_BinOp(self, node: ast.BinOp):
        """Detect Division by Zero (x / 0, x % 0)."""
        if isinstance(node.op, (ast.Div, ast.FloorDiv, ast.Mod)):
            if isinstance(node.right, ast.Constant) and node.right.value == 0:
                self.issues.append({
                    "type": "Division by Zero",
                    "category": "Logical Error",
                    "severity": "High",
                    "line": node.lineno,
                    "message": "Division or modulo by literal zero will cause ZeroDivisionError.",
                    "snippet": self._get_snippet(node.lineno)
                })
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        """Detect Unsafe eval() and exec() calls."""
        func_name = ""
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr

        if func_name in ("eval", "exec"):
            self.issues.append({
                "type": f"Unsafe {func_name}() Call",
                "category": "Security Vulnerability",
                "severity": "Critical",
                "line": node.lineno,
                "message": f"Use of '{func_name}()' allows execution of arbitrary code and presents severe security risk.",
                "snippet": self._get_snippet(node.lineno)
            })
        self.generic_visit(node)

    def visit_While(self, node: ast.While):
        """Detect Potential Infinite Loops (while True without break/return)."""
        is_always_true = False
        if isinstance(node.test, ast.Constant) and bool(node.test.value) is True:
            is_always_true = True
        elif isinstance(node.test, ast.Name) and node.test.id in ("True", "1"):
            is_always_true = True

        if is_always_true:
            has_exit = any(
                isinstance(child, (ast.Break, ast.Return))
                for child in ast.walk(node)
            )
            if not has_exit:
                self.issues.append({
                    "type": "Infinite Loop Risk",
                    "category": "Runtime Risk",
                    "severity": "High",
                    "line": node.lineno,
                    "message": "While loop condition is always True and lacks any break or return statement.",
                    "snippet": self._get_snippet(node.lineno)
                })
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        """Analyze functions for missing docstrings, length, and duplicates."""
        # Check duplicate functions
        if node.name in self.defined_functions:
            self.issues.append({
                "type": "Duplicate Function Name",
                "category": "Bad Practice",
                "severity": "Medium",
                "line": node.lineno,
                "message": f"Function '{node.name}' is defined multiple times, overriding previous definition.",
                "snippet": self._get_snippet(node.lineno)
            })
        else:
            self.defined_functions.add(node.name)

        # Check missing docstring
        docstring = ast.get_docstring(node)
        if not docstring:
            self.issues.append({
                "type": "Missing Docstring",
                "category": "Code Quality / PEP8",
                "severity": "Low",
                "line": node.lineno,
                "message": f"Function '{node.name}' is missing a docstring.",
                "snippet": self._get_snippet(node.lineno)
            })

        # Check function length
        end_line = getattr(node, "end_lineno", node.lineno)
        func_len = end_line - node.lineno + 1
        if func_len > MAX_FUNCTION_LENGTH:
            self.issues.append({
                "type": "Long Function",
                "category": "Code Complexity",
                "severity": "Medium",
                "line": node.lineno,
                "message": f"Function '{node.name}' spans {func_len} lines (exceeds recommendation of {MAX_FUNCTION_LENGTH} lines).",
                "snippet": self._get_snippet(node.lineno)
            })

        self.generic_visit(node)

    def visit_Import(self, node: ast.Import):
        """Track imported module names."""
        for alias in node.names:
            name_to_track = alias.asname if alias.asname else alias.name.split('.')[0]
            self.imported_names.add((name_to_track, node.lineno))
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        """Track imported sub-module/function names."""
        for alias in node.names:
            if alias.name != '*':
                name_to_track = alias.asname if alias.asname else alias.name
                self.imported_names.add((name_to_track, node.lineno))
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name):
        """Track used identifiers."""
        if isinstance(node.ctx, (ast.Load, ast.Del)):
            self.used_names.add(node.id)
        self.generic_visit(node)

    def _check_unused_imports(self):
        """Identify imported names that are never referenced in AST."""
        for name, lineno in self.imported_names:
            if name not in self.used_names:
                self.issues.append({
                    "type": "Unused Import",
                    "category": "Bad Practice / PEP8",
                    "severity": "Low",
                    "line": lineno,
                    "message": f"Imported module/name '{name}' is never used.",
                    "snippet": self._get_snippet(lineno)
                })

    def _get_snippet(self, lineno: int) -> str:
        """Helper to safely retrieve source code line text."""
        if 1 <= lineno <= len(self.lines):
            return self.lines[lineno - 1].strip()
        return ""
