# Fixed Code (Fallback Mode - Syntax Cleaned)
"""
app.py
------
This is the MAIN file you run to start the application.
It builds the entire user interface using Streamlit and connects
all the other files together:

    utils.py            -> reads the uploaded resume
    analyzer.py          -> sends text to OpenAI and gets analysis back
    report_generator.py  -> builds the downloadable PDF report

Run this file with:
    streamlit run app.py
"""

import os
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from dotenv import load_dotenv

import utils
import analyzer
import report_generator

# ==========================================================
# 1. PAGE CONFIG & SETUP
# ==========================================================

# Loads variables from the .env file (like OPENAI_API_KEY) into the environment
load_dotenv()

# This MUST be the first Streamlit command in the script
st.set_page_config(
    page_title="AI Resume Analyzer",
    page_icon="🧠",
    layout="wide",
)

# List of job roles the user can pick from for job-match comparison
JOB_ROLES = [
    "Data Analyst",
    "Data Scientist",
    "Python Developer",
    "Java Developer",
    "AI Engineer",
    "Full Stack Developer",
]


# ==========================================================
# 2. HELPER FUNCTIONS (specific to the UI, not general enough for utils.py)
# ==========================================================

def make_gauge_chart(value, title):
    """
    Creates a colorful "speedometer" style gauge chart using Plotly.
    Used to visually show scores like Overall Score, ATS Score, Job Match.
    """
    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=value,
            title={"text": title, "font": {"size": 18}},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": "#4CAF50" if value >= 70 else "#FFC107" if value >= 40 else "#F44336"},
                "steps": [
                    {"range": [0, 40], "color": "#ffe0e0"},
                    {"range": [40, 70], "color": "#fff6d6"},
                    {"range": [70, 100], "color": "#e2f6e2"},
                ],
            },
        )
    )
    fig.update_layout(height=250, margin=dict(l=20, r=20, t=50, b=20))
    return fig


def make_section_bar_chart(sections_dict):
    """
    Creates a horizontal bar chart showing the score of every resume
    section (Contact Info, Skills, Experience, etc.) side by side.
    """
    names = [name.replace("_", " ").title() for name in sections_dict.keys()]
    scores = [data.get("score", 0) for data in sections_dict.values()]

    df = pd.DataFrame({"Section": names, "Score": scores})
    fig = go.Figure(
        go.Bar(
            x=df["Score"],
            y=df["Section"],
            orientation="h",
            marker_color="#6C63FF",
            text=df["Score"],
            textposition="outside",
        )
    )
    fig.update_layout(
        xaxis=dict(range=[0, 100], title="Score"),
        height=350,
        margin=dict(l=10, r=10, t=20, b=20),
    )
    return fig


def display_final_verdict(overall_score, ats_score, match_percentage):
    """
    Generates a simple, friendly one-line final verdict message based
    on the average of the three main scores.
    """
    average_score = (overall_score + ats_score + match_percentage) / 3

    if average_score >= 80:
        return "🎉 Excellent! Your resume is strong and ready to apply with minor tweaks."
    elif average_score >= 60:
        return "👍 Good start! A few improvements will make your resume much more competitive."
    elif average_score >= 40:
        return "⚠️ Needs work. Follow the suggestions below to significantly boost your chances."
    else:
        return "🔧 Major improvements needed. Focus on the weaknesses and missing sections first."


# ==========================================================
# 3. SIDEBAR - Settings & Instructions
# ==========================================================

with st.sidebar:
    st.title("⚙️ Settings")

    # Let user provide their own API key if they don't have one in .env
    env_api_key = os.getenv("OPENAI_API_KEY", "")
    user_api_key = st.text_input(
        "OpenAI API Key",
        value=env_api_key,
        type="password",
        help="Get one at platform.openai.com. Stored only for this session.",
    )

    st.markdown("---")
    st.subheader("🎯 Target Job Role")
    selected_job_role = st.selectbox("Choose the role you're applying for:", JOB_ROLES)

    st.markdown("---")
    st.subheader("ℹ️ How to use")
    st.markdown(
        """
        1. Enter your OpenAI API key above
        2. Upload your resume (PDF or DOCX)
        3. Select your target job role
        4. Click **Analyze Resume**
        5. Review your scores & suggestions
        6. Download your full report
        """
    )

    st.markdown("---")
    st.caption("Built with Python, Streamlit & OpenAI")


# ==========================================================
# 4. MAIN PAGE - Title & Upload
# ==========================================================

st.title("🧠 AI Resume Analyzer")
st.markdown(
    "##### Upload your resume and get instant AI-powered feedback, "
    "an ATS score, and a personalized improvement plan."
)

st.divider()

col_upload, col_info = st.columns([2, 1])

with col_upload:
    uploaded_file = st.file_uploader(
        "📄 Upload your resume (PDF or DOCX)",
        type=["pdf", "docx"],
    )

with col_info:
    st.info(f"**Target Role:** {selected_job_role}\n\nChange this anytime in the sidebar.")

analyze_clicked = st.button("🔍 Analyze Resume", type="primary", use_container_width=True)


# ==========================================================
# 5. MAIN ANALYSIS FLOW
# ==========================================================

# We use st.session_state so results "survive" between reruns
# (Streamlit reruns the whole script on every interaction!)
if "results" not in st.session_state:
    st.session_state.results = None
if "resume_text" not in st.session_state:
    st.session_state.resume_text = ""

if analyze_clicked:
    # --- Validation checks before we do anything expensive ---
    if not user_api_key:
        st.error("⚠️ Please enter your OpenAI API key in the sidebar first.")
    elif uploaded_file is None:
        st.error("⚠️ Please upload a resume file (PDF or DOCX) first.")
    else:
        progress_bar = st.progress(0, text="Extracting text from your resume...")

        # --- Step 1: Extract text from the uploaded file ---
        raw_text = utils.extract_resume_text(uploaded_file)
        resume_text = utils.clean_text(raw_text)
        resume_text = utils.truncate_text(resume_text)

        if not resume_text or utils.count_words(resume_text) < 20:
            progress_bar.empty()
            st.error(
                "⚠️ Could not extract enough text from this file. "
                "It might be a scanned image PDF, password-protected, or empty. "
                "Please try a different file."
            )
        else:
            st.session_state.resume_text = resume_text
            progress_bar.progress(20, text="Connecting to OpenAI...")

            try:
                client = analyzer.get_openai_client(user_api_key)

                progress_bar.progress(40, text="Analyzing resume content & sections...")
                results = {}
                results["resume_analysis"] = analyzer.analyze_resume(client, resume_text)

                progress_bar.progress(55, text="Calculating ATS compatibility...")
                results["ats"] = analyzer.get_ats_score(client, resume_text)

                progress_bar.progress(65, text="Detecting technical & soft skills...")
                results["skills"] = analyzer.analyze_skills(client, resume_text)

                progress_bar.progress(80, text=f"Comparing against {selected_job_role} role...")
                results["job_match"] = analyzer.match_job_role(client, resume_text, selected_job_role)

                progress_bar.progress(90, text="Generating personalized suggestions...")
                results["suggestions"] = analyzer.get_ai_suggestions(client, resume_text, selected_job_role)

                progress_bar.progress(95, text="Analyzing keywords...")
                results["keywords"] = analyzer.analyze_keywords(client, resume_text, selected_job_role)

                progress_bar.progress(100, text="Done!")
                st.session_state.results = results
                progress_bar.empty()
                st.success("✅ Analysis complete! Scroll down to see your results.")

            except Exception as e:
                progress_bar.empty()
                st.error(
                    f"❌ Something went wrong while calling the OpenAI API.\n\n"
                    f"Error details: {e}\n\n"
                    f"Common causes: invalid API key, no internet, or rate limits."
                )


# ==========================================================
# 6. DISPLAY RESULTS (only if we have results in session_state)
# ==========================================================

results = st.session_state.results

if results:
    resume_analysis = results["resume_analysis"]
    ats = results["ats"]
    skills = results["skills"]
    job_match = results["job_match"]
    suggestions = results["suggestions"]
    keywords = results["keywords"]

    overall_score = resume_analysis.get("overall_score", 0)
    ats_score = ats.get("ats_score", 0)
    match_percentage = job_match.get("match_percentage", 0)

    st.divider()
    st.header("📊 Final Report")

    # --- Score cards (gauge charts) ---
    score_col1, score_col2, score_col3 = st.columns(3)
    with score_col1:
        st.plotly_chart(make_gauge_chart(overall_score, "Overall Resume Score"), use_container_width=True)
    with score_col2:
        st.plotly_chart(make_gauge_chart(ats_score, "ATS Score"), use_container_width=True)
    with score_col3:
        st.plotly_chart(make_gauge_chart(match_percentage, f"{selected_job_role} Match"), use_container_width=True)

    # --- Final verdict banner ---
    verdict = display_final_verdict(overall_score, ats_score, match_percentage)
    st.subheader(verdict)

    st.divider()

    # --- Section-by-section scores ---
    st.subheader("📝 Section-by-Section Evaluation")
    sections = resume_analysis.get("sections", {})
    if sections:
        st.plotly_chart(make_section_bar_chart(sections), use_container_width=True)

        for section_name, section_data in sections.items():
            readable_name = section_name.replace("_", " ").title()
            with st.expander(f"{readable_name} — Score: {section_data.get('score', 'N/A')}/100"):
                st.write(section_data.get("feedback", "No feedback available."))

    st.divider()

    # --- Strengths & Weaknesses ---
    col_strengths, col_weaknesses = st.columns(2)
    with col_strengths:
        st.subheader("✅ Strengths")
        for s in resume_analysis.get("strengths", []):
            st.markdown(f"- {s}")
    with col_weaknesses:
        st.subheader("⚠️ Weaknesses")
        for w in resume_analysis.get("weaknesses", []):
            st.markdown(f"- {w}")

    st.divider()

    # --- ATS Details ---
    with st.expander("🤖 ATS Score Explanation", expanded=False):
        st.write("**Why this score:**")
        for reason in ats.get("reasons", []):
            st.markdown(f"- {reason}")
        st.write("**How to improve:**")
        for tip in ats.get("improvement_tips", []):
            st.markdown(f"- {tip}")

    # --- Skills ---
    with st.expander("🛠️ Skill Analysis", expanded=False):
        skill_col1, skill_col2 = st.columns(2)
        with skill_col1:
            st.write("**Technical Skills Detected:**")
            st.write(", ".join(skills.get("technical_skills", [])) or "None detected")
        with skill_col2:
            st.write("**Soft Skills Detected:**")
            st.write(", ".join(skills.get("soft_skills", [])) or "None detected")

    # --- Job Match Details ---
    with st.expander(f"🎯 Job Match Details — {selected_job_role}", expanded=False):
        st.write(job_match.get("match_summary", ""))
        st.write("**Missing Skills for this role:**")
        st.write(", ".join(job_match.get("missing_skills", [])) or "None — great job!")
        st.write("**Recommended Skills to add:**")
        st.write(", ".join(job_match.get("recommended_skills", [])) or "None")

    # --- Keyword Analysis ---
    with st.expander("🔑 Keyword Analysis", expanded=False):
        st.write("**✅ Important Keywords Present:**")
        st.write(", ".join(keywords.get("important_keywords", [])) or "None found")
        st.write("**❌ Missing Keywords:**")
        st.write(", ".join(keywords.get("missing_keywords", [])) or "None")
        st.write("**🔁 Repeated Keywords (consider varying these):**")
        st.write(", ".join(keywords.get("repeated_keywords", [])) or "None")

    # --- AI Suggestions ---
    with st.expander("💡 AI Suggestions to Improve Your Resume", expanded=True):
        st.markdown(f"**Improve Summary:** {suggestions.get('improve_summary', 'N/A')}")
        st.markdown(f"**Improve Skills:** {suggestions.get('improve_skills', 'N/A')}")
        st.markdown(f"**Improve Projects:** {suggestions.get('improve_projects', 'N/A')}")
        st.markdown(f"**Improve Experience:** {suggestions.get('improve_experience', 'N/A')}")
        st.markdown(f"**Improve Formatting:** {suggestions.get('improve_formatting', 'N/A')}")

        st.write("**Grammar Suggestions:**")
        for g in suggestions.get("grammar_suggestions", []):
            st.markdown(f"- {g}")

        st.write("**Suggested Strong Action Verbs:**")
        st.write(", ".join(suggestions.get("strong_action_verbs", [])) or "None")

    st.divider()

    # --- Download Report Button ---
    st.subheader("📥 Download Your Report")
    pdf_bytes = report_generator.generate_pdf_report(results, selected_job_role)
    st.download_button(
        label="Download Full Report (PDF)",
        data=pdf_bytes,
        file_name="resume_analysis_report.pdf",
        mime="application/pdf",
        use_container_width=True,
    )

else:
    st.info("👆 Upload a resume and click **Analyze Resume** to get started.")