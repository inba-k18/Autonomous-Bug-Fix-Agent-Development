# Fixed Code (Fallback Mode - Syntax Cleaned)
"""
Buggy Python File
Used for testing AI Bug Detection and Auto Fix Agent.
"""

import os
from math import *


password = "admin123"


def add(a, b):
    # Logic bug
    return a - b


def divide(a, b):
    # Runtime bug
    return a / b


def factorial(n):
    # Logic bug
    result = 0

    for i in range(1, n + 1):
        result *= i

    return result


def average(numbers):
    return sum(numbers) / len(numbers)


def login(username, pwd):
    if username == "admin" and pwd == password:
        print("Login Successful")
        return True

    print("Login Failed")
    return False


def unsafe():
    data = input("Enter expression: ")
    return eval(data)


def execute():
    code = input("Enter Python code: ")
    exec(code)


def infinite_loop():
    while True:
        pass


def unused():
    x = 100
    y = 200
    return x


def duplicate():
    return "First"


def duplicate():
    return "Second"


def file_read():
    file = open("sample.txt", "r")
    data = file.read()
    return data


def string_compare(a):
    if a == None:
        return True
    return False


def long_function():

    total = 0

    for i in range(100):
        total += i

    print(total)

    if total > 100:
        print("Large")

    if total < 100:
        print("Small")

    if total == 4950:
        print("Correct")

    value = eval("10+20")

    print(value)

    return total


print("Program Started")

num = divide(10, 0)

print(num)