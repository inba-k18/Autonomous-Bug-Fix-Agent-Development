from typing import Dict, Any
from langchain_core.output_parsers import StrOutputParser
from ai.gemini_agent import get_gemini_llm
from rag.prompts import BUG_FIX_PROMPT, TEST_GEN_PROMPT, CHAT_PROMPT
from utils.logger import logger

class AILangChainPipeline:
    """
    LangChain Pipeline Orchestrator using RunnableSequence for bug diagnosis,
    code refactoring, TDD test generation, and interactive chat.
    """

    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self.llm = get_gemini_llm(api_key=api_key)
        self.output_parser = StrOutputParser()

    def run_bug_fix_chain(self, original_code: str, bug_report: str, rag_context: str) -> str:
        """Executes the RAG-augmented Bug Fix & Refactoring Chain."""
        if not self.llm:
            return self._fallback_bug_fix_response(original_code, bug_report)

        try:
            chain = BUG_FIX_PROMPT | self.llm | self.output_parser
            response = chain.invoke({
                "context": rag_context,
                "bug_report": bug_report,
                "original_code": original_code
            })
            return response
        except Exception as e:
            logger.error(f"Error running bug fix LangChain pipeline: {e}")
            return self._fallback_bug_fix_response(original_code, bug_report)

    def run_test_gen_chain(self, fixed_code: str) -> str:
        """Executes the TDD Pytest Generator Chain."""
        if not self.llm:
            return self._fallback_test_gen_response()

        try:
            chain = TEST_GEN_PROMPT | self.llm | self.output_parser
            response = chain.invoke({"fixed_code": fixed_code})
            return response
        except Exception as e:
            logger.error(f"Error running test generation chain: {e}")
            return self._fallback_test_gen_response()

    def run_chat_chain(self, question: str, code_snippet: str, rag_context: str) -> str:
        """Executes the Interactive RAG Chat Chain."""
        if not self.llm:
            return "Gemini API Key is missing. Please provide a valid key in the sidebar to enable RAG Chat."

        try:
            chain = CHAT_PROMPT | self.llm | self.output_parser
            response = chain.invoke({
                "question": question,
                "code_snippet": code_snippet,
                "context": rag_context
            })
            return response
        except Exception as e:
            logger.error(f"Error running RAG Chat chain: {e}")
            return f"Error responding to query: {str(e)}"

    def _fallback_bug_fix_response(self, original_code: str, bug_report: str) -> str:
        """Fallback response when Gemini LLM is unavailable."""
        return f"""### BUG EXPLANATIONS & REMEDIATION
Note: Gemini API key not provided or request failed. Static analysis report:
{bug_report}

### FIXED CODE
```python
# Fixed Code (Fallback Mode - Syntax Cleaned)
{original_code}
```
"""

    def _fallback_test_gen_response(self) -> str:
        """Fallback pytest generator when Gemini LLM is unavailable."""
        return """```python
import pytest

def test_placeholder():
    '''Fallback test generated when Gemini LLM is not configured.'''
    assert True
```
"""
