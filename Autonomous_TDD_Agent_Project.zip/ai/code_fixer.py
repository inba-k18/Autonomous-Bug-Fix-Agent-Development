import re
from pathlib import Path
from typing import Dict, Any, Tuple
from config import UPLOADS_DIR
from utils.helpers import clean_markdown_code_block, compute_code_diff, save_file
from utils.logger import logger

class CodeFixer:
    """
    Code Fixer Engine that handles AI output parsing, saving fixed Python files
    to `uploads/{filename}_fixed.py`, and calculating line modification metrics.
    """

    def __init__(self, original_filepath: Path):
        self.original_filepath = original_filepath
        self.original_filename = original_filepath.name
        self.fixed_filename = f"{original_filepath.stem}_fixed.py"
        self.fixed_filepath = UPLOADS_DIR / self.fixed_filename

    def process_ai_response(self, original_code: str, ai_response_text: str) -> Dict[str, Any]:
        """
        Parses LLM response into explanation section and code section,
        saves fixed file, and calculates diff metrics.
        """
        explanations, fixed_code = self._parse_response(ai_response_text)

        # Fallback to original code if fixed_code extraction failed
        if not fixed_code.strip():
            fixed_code = original_code

        # Save fixed file without modifying original
        saved_path = save_file(self.fixed_filepath, fixed_code)

        # Compute code diff
        diff_data = compute_code_diff(original_code, fixed_code)

        return {
            "fixed_filepath": str(saved_path),
            "fixed_filename": self.fixed_filename,
            "explanations": explanations,
            "fixed_code": fixed_code,
            "diff_stats": diff_data["stats"],
            "diff_records": diff_data["records"]
        }

    def _parse_response(self, text: str) -> Tuple[str, str]:
        """Extracts text explanations and markdown python block."""
        explanations = ""
        fixed_code = ""

        # Extract python code block
        code_block_match = re.search(r'```python(.*?)```', text, re.DOTALL)
        if code_block_match:
            fixed_code = clean_markdown_code_block(code_block_match.group(0))
            # Text outside code block is explanation
            explanations = text.replace(code_block_match.group(0), "").strip()
        else:
            explanations = text
            fixed_code = clean_markdown_code_block(text)

        return explanations, fixed_code
