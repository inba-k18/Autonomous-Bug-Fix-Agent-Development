from typing import Any
from config import GEMINI_API_KEY, DEFAULT_MODEL
from utils.logger import logger

def get_gemini_llm(api_key: str = None, model_name: str = None, temperature: float = 0.2) -> Any:
    """
    Initializes and returns a ChatGoogleGenerativeAI instance.
    """
    key = api_key or GEMINI_API_KEY
    model = model_name or DEFAULT_MODEL

    if not key:
        logger.warning("No Gemini API Key provided. AI generation functions will operate in simulated mode.")
        return None

    try:
        from langchain_google_genai import ChatGoogleGenerativeAI
        logger.info(f"Initializing ChatGoogleGenerativeAI with model {model}...")
        llm = ChatGoogleGenerativeAI(
            model=model,
            google_api_key=key,
            temperature=temperature,
            max_output_tokens=4096
        )
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize ChatGoogleGenerativeAI: {e}")
        return None
