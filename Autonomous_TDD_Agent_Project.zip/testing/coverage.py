import re
from typing import Dict, Any

class CoverageParser:
    """
    Parses Pytest and pytest-cov outputs to extract code coverage stats.
    """

    @staticmethod
    def parse_coverage_output(stdout_text: str) -> Dict[str, Any]:
        """
        Extracts coverage percentage, total statements, covered statements,
        and missed lines from pytest-cov stdout output table.
        """
        coverage_pct = 0.0
        total_statements = 0
        missed_statements = 0
        
        # Look for standard pytest-cov TOTAL row (e.g., TOTAL 15 2 87%)
        total_match = re.search(r'TOTAL\s+(\d+)\s+(\d+)\s+(\d+)%', stdout_text)
        if total_match:
            total_statements = int(total_match.group(1))
            missed_statements = int(total_match.group(2))
            coverage_pct = float(total_match.group(3))
        else:
            # Fallback regex for percentage match (e.g. Coverage: 85%)
            pct_match = re.search(r'(\d+(?:\.\d+)?)%\s*(?:coverage)?', stdout_text, re.IGNORECASE)
            if pct_match:
                coverage_pct = float(pct_match.group(1))
            else:
                coverage_pct = 100.0 if "PASSED" in stdout_text else 0.0

        return {
            "coverage_pct": round(coverage_pct, 1),
            "total_statements": total_statements,
            "missed_statements": missed_statements,
            "covered_statements": max(0, total_statements - missed_statements)
        }
