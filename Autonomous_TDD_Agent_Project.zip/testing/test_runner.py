import sys
import subprocess
import time
import re
from pathlib import Path
from typing import Dict, Any
from testing.coverage import CoverageParser
from utils.logger import logger

class TestRunner:
    """
    Automated Pytest Execution Engine that invokes pytest process,
    parses pass/fail results, measures execution latency, and computes coverage.
    """

    def __init__(self, test_filepath: Path, target_source_filepath: Path):
        self.test_filepath = test_filepath
        self.target_source_filepath = target_source_filepath

    def execute_tests(self) -> Dict[str, Any]:
        """
        Executes pytest subprocess command and parses test results & coverage.
        """
        start_time = time.time()
        
        # Build pytest command line with coverage flags if pytest-cov installed
        cmd = [
            sys.executable, "-m", "pytest",
            str(self.test_filepath),
            "-v",
            f"--cov={self.target_source_filepath.parent}",
            "--cov-report=term-missing"
        ]

        logger.info(f"Executing pytest command: {' '.join(cmd)}")
        
        try:
            res = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=30
            )
            stdout = res.stdout
            exit_code = res.returncode
        except subprocess.TimeoutExpired:
            stdout = "Pytest execution timed out after 30 seconds."
            exit_code = -1
        except Exception as e:
            stdout = f"Failed to execute pytest process: {str(e)}"
            exit_code = -1

        execution_time = round(time.time() - start_time, 2)

        # Parse test metrics from stdout
        passed_count = 0
        failed_count = 0
        skipped_count = 0
        total_count = 0

        # Pattern match pytest summary line (e.g. 3 passed, 1 failed in 0.12s)
        pass_match = re.search(r'(\d+)\s+passed', stdout)
        fail_match = re.search(r'(\d+)\s+failed', stdout)
        skip_match = re.search(r'(\d+)\s+skipped', stdout)

        if pass_match:
            passed_count = int(pass_match.group(1))
        if fail_match:
            failed_count = int(fail_match.group(1))
        if skip_match:
            skipped_count = int(skip_match.group(1))

        total_count = passed_count + failed_count + skipped_count

        # Parse coverage statistics
        cov_stats = CoverageParser.parse_coverage_output(stdout)

        return {
            "exit_code": exit_code,
            "success": exit_code == 0,
            "passed_count": passed_count,
            "failed_count": failed_count,
            "skipped_count": skipped_count,
            "total_count": total_count,
            "execution_time_seconds": execution_time,
            "coverage_pct": cov_stats["coverage_pct"],
            "coverage_stats": cov_stats,
            "stdout": stdout
        }
