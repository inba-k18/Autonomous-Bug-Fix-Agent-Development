import re
from pathlib import Path
from typing import Dict, Any
from config import TESTS_DIR, UPLOADS_DIR
from ai.langchain_pipeline import AILangChainPipeline
from utils.helpers import clean_markdown_code_block, save_file
from utils.logger import logger

class TestGenerator:
    """
    TDD Test Suite Generator that requests AI to build pytest cases,
    injects dynamic import hooks pointing to `uploads/`, and saves to `tests/`.
    """

    def __init__(self, fixed_filepath: Path, api_key: str = None):
        self.fixed_filepath = fixed_filepath
        self.fixed_filename = fixed_filepath.name
        self.test_filename = f"test_{fixed_filepath.stem}.py"
        self.test_filepath = TESTS_DIR / self.test_filename
        self.ai_pipeline = AILangChainPipeline(api_key=api_key)

    def generate_and_save_tests(self, fixed_code: str) -> Dict[str, Any]:
        """
        Generates pytest unit test suite, adds import boilerplates,
        and saves test file under `tests/`.
        """
        raw_ai_test_code = self.ai_pipeline.run_test_gen_chain(fixed_code)
        cleaned_test_code = clean_markdown_code_block(raw_ai_test_code)

        # Inject sys.path resolution so pytest can import the fixed file from uploads
        import_header = f"""import sys
from pathlib import Path

# Dynamic import path setup for uploaded fixed module
UPLOADS_DIR = Path(r"{UPLOADS_DIR.resolve()}").resolve()
if str(UPLOADS_DIR) not in sys.path:
    sys.path.insert(0, str(UPLOADS_DIR))

# Import fixed target module
import {self.fixed_filepath.stem} as target_module
from {self.fixed_filepath.stem} import *
"""

        # Avoid duplicate imports if AI already included sys.path
        if "sys.path" not in cleaned_test_code:
            final_test_code = f"{import_header}\n{cleaned_test_code}"
        else:
            final_test_code = cleaned_test_code

        saved_path = save_file(self.test_filepath, final_test_code)

        return {
            "test_filepath": str(saved_path),
            "test_filename": self.test_filename,
            "test_code": final_test_code
        }
