import datetime
from pathlib import Path
from typing import Dict, Any
from config import REPORTS_DIR
from utils.helpers import save_file
from utils.logger import logger

class PDFReportGenerator:
    """
    PDF Report Generator creating formatted PDF documents.
    Uses ReportLab if available, falling back to TXT wrapper if ReportLab is missing.
    """

    @staticmethod
    def generate(data: Dict[str, Any], filename: str = "TDD_Report.pdf") -> Path:
        """Generates and saves PDF analysis report."""
        filepath = REPORTS_DIR / filename
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Preformatted
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

            doc = SimpleDocTemplate(str(filepath), pagesize=letter)
            styles = getSampleStyleSheet()

            # Custom styles
            title_style = ParagraphStyle('TitleStyle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor("#1e3a8a"), spaceAfter=12)
            h2_style = ParagraphStyle('H2Style', parent=styles['Heading2'], fontSize=14, textColor=colors.HexColor("#1d4ed8"), spaceBefore=12, spaceAfter=6)
            normal_style = styles['Normal']
            code_style = ParagraphStyle('CodeStyle', parent=styles['Normal'], fontName='Courier', fontSize=8, leading=10, textColor=colors.HexColor("#1e293b"))

            story = []

            # Title
            story.append(Paragraph("Autonomous Bug Fix & TDD Agent Report", title_style))
            story.append(Paragraph(f"<b>Date:</b> {now} | <b>File:</b> {data.get('original_filename', '')}", normal_style))
            story.append(Spacer(1, 12))

            # Overview metrics table
            bug_rep = data.get("bug_report", {})
            test_res = data.get("test_results", {})
            
            metrics_data = [
                ["Total Bugs", "Passed Tests", "Code Coverage", "Execution Time"],
                [
                    str(bug_rep.get("total_issues", 0)),
                    f"{test_res.get('passed_count', 0)} / {test_res.get('total_count', 0)}",
                    f"{test_res.get('coverage_pct', 0.0)}%",
                    f"{test_res.get('execution_time_seconds', 0.0)}s"
                ]
            ]
            
            metrics_table = Table(metrics_data, colWidths=[120, 120, 120, 120])
            metrics_table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#3b82f6")),
                ('TEXTCOLOR', (0,0), (-1,0), colors.white),
                ('ALIGN', (0,0), (-1,-1), 'CENTER'),
                ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
                ('BOTTOMPADDING', (0,0), (-1,0), 6),
                ('BACKGROUND', (0,1), (-1,1), colors.HexColor("#f1f5f9")),
                ('GRID', (0,0), (-1,-1), 1, colors.HexColor("#cbd5e1")),
            ]))
            story.append(metrics_table)
            story.append(Spacer(1, 14))

            # Section 1: Detected Bugs
            story.append(Paragraph("1. Static Bug Analysis", h2_style))
            issues = bug_rep.get("issues", [])
            if issues:
                table_data = [["Line", "Severity", "Type", "Description"]]
                for issue in issues[:15]: # Cap at 15 for clean PDF layout
                    table_data.append([
                        str(issue.get("line", "?")),
                        str(issue.get("severity", "Low")),
                        str(issue.get("type", "Bug")),
                        Paragraph(issue.get("message", ""), normal_style)
                    ])
                issues_table = Table(table_data, colWidths=[40, 60, 120, 260])
                issues_table.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#1e293b")),
                    ('TEXTCOLOR', (0,0), (-1,0), colors.white),
                    ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#94a3b8")),
                    ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ]))
                story.append(issues_table)
            else:
                story.append(Paragraph("No static bugs detected.", normal_style))

            story.append(Spacer(1, 14))

            # Section 2: Fixed Code Preview
            story.append(Paragraph("2. Fixed Python Code Snippet", h2_style))
            fixed_snippet = data.get("fixed_code", "")[:1000] # First 1000 chars for PDF
            story.append(Preformatted(fixed_snippet, code_style))

            story.append(Spacer(1, 14))

            # Section 3: Generated Test Code Preview
            story.append(Paragraph("3. Generated Pytest Suite Snippet", h2_style))
            test_snippet = data.get("test_code", "")[:1000]
            story.append(Preformatted(test_snippet, code_style))

            doc.build(story)
            logger.info(f"Successfully generated PDF report at {filepath}")
            return filepath

        except Exception as e:
            logger.warning(f"ReportLab PDF generation failed ({e}). Writing plain text wrapper PDF.")
            # Fallback text wrapper if ReportLab fails
            filepath.write_text(f"PDF Report Placeholder\n\nGenerated: {now}\nFile: {data.get('original_filename')}\nTotal Bugs: {data.get('bug_report', {}).get('total_issues')}\nCoverage: {data.get('test_results', {}).get('coverage_pct')}%\n")
            return filepath
