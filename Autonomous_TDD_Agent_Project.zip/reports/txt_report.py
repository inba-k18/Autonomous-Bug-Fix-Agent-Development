import datetime
from pathlib import Path
from typing import Dict, Any
from config import REPORTS_DIR
from utils.helpers import save_file

class TXTReportGenerator:
    """
    Plain Text Report Generator for Autonomous Bug Fix & TDD Agent.
    """

    @staticmethod
    def generate(data: Dict[str, Any], filename: str = "TDD_Report.txt") -> Path:
        """Generates and saves plain text analysis report."""
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        filepath = REPORTS_DIR / filename

        report_content = f"""================================================================================
AUTONOMOUS BUG FIX & TEST-DRIVEN DEVELOPMENT (TDD) AGENT REPORT
================================================================================
Project Name: {data.get("project_name", "Autonomous TDD Agent Project")}
Date Generated: {now}
Target File: {data.get("original_filename", "N/A")}
Fixed File: {data.get("fixed_filename", "N/A")}
--------------------------------------------------------------------------------

1. CODE METRICS & OVERVIEW
- Syntax Valid: {data.get("bug_report", {}).get("is_valid_syntax", True)}
- Total Bugs Detected: {data.get("bug_report", {}).get("total_issues", 0)}
- Critical Issues: {data.get("bug_report", {}).get("severity_counts", {}).get("Critical", 0)}
- High Issues: {data.get("bug_report", {}).get("severity_counts", {}).get("High", 0)}
- Medium Issues: {data.get("bug_report", {}).get("severity_counts", {}).get("Medium", 0)}
- Low Issues: {data.get("bug_report", {}).get("severity_counts", {}).get("Low", 0)}

--------------------------------------------------------------------------------
2. DETECTED BUGS & STATIC ANALYSIS
"""
        issues = data.get("bug_report", {}).get("issues", [])
        if issues:
            for idx, issue in enumerate(issues, start=1):
                report_content += f"""
[{idx}] Line {issue.get('line', '?')} | {issue.get('severity', 'Low').upper()} | {issue.get('category', 'General')}
    Type: {issue.get('type', 'Bug')}
    Description: {issue.get('message', '')}
    Snippet: {issue.get('snippet', '')}
"""
        else:
            report_content += "\nNo static bugs detected.\n"

        report_content += f"""
--------------------------------------------------------------------------------
3. RETRIEVED PYTHON KNOWLEDGE BASE CONTEXT
--------------------------------------------------------------------------------
{data.get("rag_context", "No context available.")}

--------------------------------------------------------------------------------
4. AI BUG EXPLANATION & REMEDIATION
--------------------------------------------------------------------------------
{data.get("explanations", "No explanation provided.")}

--------------------------------------------------------------------------------
5. FIXED CODE (uploads/{data.get("fixed_filename", "fixed.py")})
--------------------------------------------------------------------------------
{data.get("fixed_code", "")}

--------------------------------------------------------------------------------
6. GENERATED PYTEST SUITE
--------------------------------------------------------------------------------
{data.get("test_code", "")}

--------------------------------------------------------------------------------
7. PYTEST EXECUTION & COVERAGE METRICS
--------------------------------------------------------------------------------
- Test Execution Status: {"PASSED" if data.get("test_results", {}).get("success") else "FAILED"}
- Passed Tests: {data.get("test_results", {}).get("passed_count", 0)}
- Failed Tests: {data.get("test_results", {}).get("failed_count", 0)}
- Total Tests: {data.get("test_results", {}).get("total_count", 0)}
- Code Coverage: {data.get("test_results", {}).get("coverage_pct", 0.0)}%
- Execution Time: {data.get("test_results", {}).get("execution_time_seconds", 0.0)}s

Pytest Console Output:
{data.get("test_results", {}).get("stdout", "")}

--------------------------------------------------------------------------------
8. RECOMMENDATIONS & BEST PRACTICES
--------------------------------------------------------------------------------
- Maintain 100% test pass rate in CI/CD pipeline before code merges.
- Keep unit tests updated whenever adding new software requirements.
- Follow PEP8 styling guidelines and enforce automated pre-commit hooks.
- Store sensitive configuration credentials in .env files rather than source code.

================================================================================
END OF REPORT
================================================================================
"""
        return save_file(filepath, report_content)
