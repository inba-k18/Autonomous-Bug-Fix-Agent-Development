import datetime
import html
from pathlib import Path
from typing import Dict, Any
from config import REPORTS_DIR
from utils.helpers import save_file

class HTMLReportGenerator:
    """
    HTML Report Generator creating styled, interactive HTML reports.
    """

    @staticmethod
    def generate(data: Dict[str, Any], filename: str = "TDD_Report.html") -> Path:
        """Generates and saves styled HTML analysis report."""
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        filepath = REPORTS_DIR / filename

        issues = data.get("bug_report", {}).get("issues", [])
        issues_rows = ""
        for idx, issue in enumerate(issues, start=1):
            sev = issue.get("severity", "Low")
            sev_class = "badge-high" if sev in ("Critical", "High") else ("badge-medium" if sev == "Medium" else "badge-low")
            issues_rows += f"""
            <tr>
                <td>{idx}</td>
                <td>Line {issue.get('line', '?')}</td>
                <td><span class="badge {sev_class}">{html.escape(sev)}</span></td>
                <td>{html.escape(issue.get('category', ''))}</td>
                <td><strong>{html.escape(issue.get('type', ''))}</strong>: {html.escape(issue.get('message', ''))}</td>
                <td><code>{html.escape(issue.get('snippet', ''))}</code></td>
            </tr>
            """

        if not issues_rows:
            issues_rows = '<tr><td colspan="6" style="text-align:center;">No static bugs detected.</td></tr>'

        test_res = data.get("test_results", {})
        cov_pct = test_res.get("coverage_pct", 0.0)
        passed = test_res.get("passed_count", 0)
        failed = test_res.get("failed_count", 0)
        exec_time = test_res.get("execution_time_seconds", 0.0)

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autonomous TDD Agent Report</title>
    <style>
        :root {{
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --accent-blue: #38bdf8;
            --accent-green: #4ade80;
            --accent-red: #f87171;
            --accent-orange: #fb923c;
            --border-color: #334155;
        }}
        body {{
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-main);
            margin: 0;
            padding: 2rem;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .header {{
            text-align: center;
            padding-bottom: 2rem;
            border-bottom: 1px solid var(--border-color);
        }}
        .header h1 {{
            color: var(--accent-blue);
            margin-bottom: 0.5rem;
        }}
        .grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }}
        .card {{
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            text-align: center;
        }}
        .card .metric {{
            font-size: 2.2rem;
            font-weight: bold;
            color: var(--accent-blue);
            margin-top: 0.5rem;
        }}
        .card .metric.green {{ color: var(--accent-green); }}
        .card .metric.red {{ color: var(--accent-red); }}
        .section {{
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }}
        .section h2 {{
            color: var(--accent-blue);
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.5rem;
            margin-top: 0;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }}
        th, td {{
            padding: 0.75rem 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }}
        th {{
            background-color: #0f172a;
            color: var(--text-muted);
        }}
        .badge {{
            padding: 0.25rem 0.6rem;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: bold;
        }}
        .badge-high {{ background-color: #991b1b; color: #fecaca; }}
        .badge-medium {{ background-color: #9a3412; color: #ffedd5; }}
        .badge-low {{ background-color: #1e3a8a; color: #dbeafe; }}
        pre {{
            background-color: #0f172a;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1rem;
            overflow-x: auto;
            color: #e2e8f0;
            font-family: 'Consolas', monospace;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Autonomous Bug Fix & TDD Agent Report</h1>
            <p style="color: var(--text-muted);">Generated on {now} | Target File: {html.escape(data.get('original_filename', ''))}</p>
        </div>

        <div class="grid">
            <div class="card">
                <div>Total Bugs Detected</div>
                <div class="metric">{data.get("bug_report", {}).get("total_issues", 0)}</div>
            </div>
            <div class="card">
                <div>Tests Passed / Total</div>
                <div class="metric green">{passed} / {passed + failed}</div>
            </div>
            <div class="card">
                <div>Code Coverage</div>
                <div class="metric green">{cov_pct}%</div>
            </div>
            <div class="card">
                <div>Execution Time</div>
                <div class="metric">{exec_time}s</div>
            </div>
        </div>

        <div class="section">
            <h2>1. Static Bug Analysis</h2>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Line</th>
                        <th>Severity</th>
                        <th>Category</th>
                        <th>Issue Description</th>
                        <th>Code Snippet</th>
                    </tr>
                </thead>
                <tbody>
                    {issues_rows}
                </tbody>
            </table>
        </div>

        <div class="section">
            <h2>2. Retrieved RAG Knowledge Base Context</h2>
            <pre>{html.escape(data.get("rag_context", "No RAG context"))}</pre>
        </div>

        <div class="section">
            <h2>3. AI Bug Explanation & Remediation</h2>
            <div>{html.escape(data.get("explanations", "")).replace("\n", "<br>")}</div>
        </div>

        <div class="section">
            <h2>4. Fixed Python Code (uploads/{html.escape(data.get("fixed_filename", ""))})</h2>
            <pre>{html.escape(data.get("fixed_code", ""))}</pre>
        </div>

        <div class="section">
            <h2>5. Generated Pytest Unit Tests</h2>
            <pre>{html.escape(data.get("test_code", ""))}</pre>
        </div>

        <div class="section">
            <h2>6. Pytest Execution Log</h2>
            <pre>{html.escape(test_res.get("stdout", ""))}</pre>
        </div>
    </div>
</body>
</html>
"""
        return save_file(filepath, html_content)
