from langchain_core.prompts import PromptTemplate

# Prompt Template for Bug Explanation and Refactoring with RAG Context
BUG_FIX_RAG_PROMPT_TEMPLATE = """You are an expert Python Developer and Autonomous TDD Agent.
Analyze the provided Python source code and static bug analysis findings. Use the retrieved Python documentation context to explain each bug and provide a fully corrected version of the code.

==================================================
RETRIEVED PYTHON DOCUMENTATION CONTEXT:
==================================================
{context}

==================================================
DETECTED BUGS & STATIC ANALYSIS FINDINGS:
==================================================
{bug_report}

==================================================
ORIGINAL PYTHON CODE:
==================================================
```python
{original_code}
```

==================================================
YOUR TASK:
==================================================
1. EXPLAIN BUGS: List each detected bug, explain why it occurs, and describe the best fix using official Python best practices.
2. REWRITE CODE: Provide the complete, refactored, and fixed Python code.
   - The refactored code MUST fix all syntax errors, logical errors, security vulnerabilities, infinite loops, and PEP8 violations.
   - Do NOT omit any existing function, class, or functionality unless refactoring requires it.
   - Add proper docstrings and clean formatting.

FORMAT YOUR RESPONSE EXACTLY AS FOLLOWS:

### BUG EXPLANATIONS & REMEDIATION
- **[Bug Type]**: (Explanation of why it occurs and recommended fix)

### FIXED CODE
```python
# Put the complete fixed Python code here
```
"""

BUG_FIX_PROMPT = PromptTemplate(
    template=BUG_FIX_RAG_PROMPT_TEMPLATE,
    input_variables=["context", "bug_report", "original_code"]
)


# Prompt Template for Pytest Unit Test Generation
TEST_GENERATION_PROMPT_TEMPLATE = """You are an expert Python Test Engineer following Test-Driven Development (TDD) principles.
Generate a comprehensive, production-ready `pytest` unit test file for the provided fixed Python code.

==================================================
FIXED PYTHON CODE TO TEST:
==================================================
```python
{fixed_code}
```

==================================================
TEST REQUIREMENTS:
==================================================
1. Use standard `pytest` syntax and functions.
2. Write unit tests covering:
   - Happy path / standard inputs
   - Edge cases & boundary values (empty strings, zeros, negative numbers, large lists)
   - Expected exception assertions using `pytest.raises(...)` where appropriate.
3. Import the functions/classes to test directly or assume they exist in the module.
4. Ensure the output is ONLY valid executable Python code for the test file.

FORMAT YOUR RESPONSE EXACTLY AS FOLLOWS:

```python
import pytest
# Complete pytest test suite code
```
"""

TEST_GEN_PROMPT = PromptTemplate(
    template=TEST_GENERATION_PROMPT_TEMPLATE,
    input_variables=["fixed_code"]
)


# Prompt Template for RAG Code Chat Interface
CODE_CHAT_PROMPT_TEMPLATE = """You are an AI Coding Assistant specializing in Python, RAG, and TDD.
Answer the user's question based on the uploaded code snippet and retrieved Python knowledge base.

RETRIEVED CONTEXT:
{context}

CODE SNIPPET:
{code_snippet}

USER QUESTION:
{question}

Provide a helpful, precise, and concise answer with code examples if relevant.
"""

CHAT_PROMPT = PromptTemplate(
    template=CODE_CHAT_PROMPT_TEMPLATE,
    input_variables=["context", "code_snippet", "question"]
)
