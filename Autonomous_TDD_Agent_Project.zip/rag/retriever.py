from typing import List, Any
from rag.vector_store import VectorStoreManager
from utils.logger import logger

class RAGRetriever:
    """
    RAG Information Retrieval Pipeline that queries the vector database
    for relevant Python guidelines, documentation, and error patterns.
    """

    def __init__(self, api_key: str = None):
        self.vector_manager = VectorStoreManager(api_key=api_key)
        self.vector_store = self.vector_manager.build_or_load_vector_store()

    def retrieve_context_for_bugs(self, bug_report: dict, original_code: str) -> str:
        """
        Constructs targeted queries based on detected bugs and retrieves context.
        """
        if not self.vector_store:
            return "No vector store available. Proceeding with general Python knowledge."

        # Collect search query keywords
        categories = list(bug_report.get("category_counts", {}).keys())
        issue_types = [issue.get("type", "") for issue in bug_report.get("issues", [])]
        
        query_terms = list(set(categories + issue_types))
        query_str = " ".join(query_terms) if query_terms else "Python PEP8 security error best practices"

        try:
            retriever = self.vector_store.as_retriever(search_kwargs={"k": 4})
            docs = retriever.invoke(query_str)
            
            context_blocks = []
            for idx, doc in enumerate(docs, start=1):
                source = doc.metadata.get("source", "Knowledge Base")
                context_blocks.append(f"--- Doc Chunk #{idx} (Source: {source}) ---\n{doc.page_content}")

            return "\n\n".join(context_blocks)

        except Exception as e:
            logger.error(f"Error during RAG context retrieval: {e}")
            return "Error retrieving documentation context from RAG vector database."
