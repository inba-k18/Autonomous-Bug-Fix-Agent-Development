from typing import Any
from config import GEMINI_API_KEY, EMBEDDINGS_MODEL
from utils.logger import logger

def get_embeddings_model(api_key: str = None) -> Any:
    """
    Initializes and returns GoogleGenerativeAIEmbeddings.
    Falls back gracefully if API key or library is unavailable.
    """
    key = api_key or GEMINI_API_KEY

    if key:
        try:
            from langchain_google_genai import GoogleGenerativeAIEmbeddings
            logger.info("Initializing GoogleGenerativeAIEmbeddings...")
            return GoogleGenerativeAIEmbeddings(
                model=EMBEDDINGS_MODEL,
                google_api_key=key
            )
        except Exception as e:
            logger.warning(f"GoogleGenerativeAIEmbeddings initialization failed: {e}. Falling back...")

    # Fallback to HuggingFace Embeddings if installed, or fake embeddings for local testing
    try:
        from langchain_community.embeddings import HuggingFaceEmbeddings
        logger.info("Initializing HuggingFaceEmbeddings (all-MiniLM-L6-v2)...")
        return HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    except Exception as e:
        logger.warning(f"HuggingFaceEmbeddings fallback failed: {e}. Using FakeEmbeddings.")
        from langchain_community.embeddings import FakeEmbeddings
        return FakeEmbeddings(size=384)
