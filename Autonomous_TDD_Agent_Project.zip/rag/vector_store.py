import os
from pathlib import Path
from typing import Any, List
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from config import KNOWLEDGE_BASE_DIR, VECTOR_STORE_DIR
from rag.embeddings import get_embeddings_model
from utils.logger import logger

class VectorStoreManager:
    """
    Vector Store Manager using ChromaDB (or FAISS fallback) for persisting
    and querying the Python Documentation knowledge base.
    """

    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self.embeddings = get_embeddings_model(api_key)
        self.vector_store = None

    def build_or_load_vector_store(self, force_rebuild: bool = False) -> Any:
        """
        Loads existing vector store or builds a new one from knowledge_base documents.
        """
        # Try loading Chroma vector store first
        try:
            try:
                from langchain_chroma import Chroma
            except ImportError:
                from langchain_community.vectorstores import Chroma

            if VECTOR_STORE_DIR.exists() and any(VECTOR_STORE_DIR.iterdir()) and not force_rebuild:
                logger.info("Loading existing Chroma vector store...")
                self.vector_store = Chroma(
                    persist_directory=str(VECTOR_STORE_DIR),
                    embedding_function=self.embeddings
                )
                return self.vector_store

            logger.info("Building new Chroma vector store from knowledge base...")
            documents = self._load_documents()
            if not documents:
                logger.warning("No knowledge base documents found. Vector store will be empty.")
                documents = [Document(page_content="Python PEP8 and Error Debugging Guide.", metadata={"source": "default"})]

            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=600,
                chunk_overlap=100
            )
            chunks = text_splitter.split_documents(documents)
            
            self.vector_store = Chroma.from_documents(
                documents=chunks,
                embedding=self.embeddings,
                persist_directory=str(VECTOR_STORE_DIR)
            )
            logger.info(f"Successfully built Chroma vector store with {len(chunks)} chunks.")
            return self.vector_store

        except Exception as e:
            logger.warning(f"ChromaDB initialization failed: {e}. Attempting FAISS fallback...")
            return self._build_faiss_fallback()

    def _load_documents(self) -> List[Document]:
        """Loads all markdown and txt files from knowledge_base directory directly into Document objects."""
        docs = []
        if not KNOWLEDGE_BASE_DIR.exists():
            return docs

        try:
            # 1. Try DirectoryLoader from langchain_community if available
            try:
                from langchain_community.document_loaders import DirectoryLoader, TextLoader
                for ext in ["*.md", "*.txt"]:
                    loader = DirectoryLoader(
                        str(KNOWLEDGE_BASE_DIR),
                        glob=ext,
                        loader_cls=TextLoader,
                        loader_kwargs={"encoding": "utf-8"}
                    )
                    docs.extend(loader.load())
                if docs:
                    return docs
            except Exception as e:
                logger.info(f"DirectoryLoader unavailable ({e}). Using direct file reader.")

            # 2. Direct file system reader fallback
            for filepath in KNOWLEDGE_BASE_DIR.rglob("*"):
                if filepath.suffix.lower() in [".md", ".txt"]:
                    try:
                        content = filepath.read_text(encoding="utf-8", errors="ignore")
                        if content.strip():
                            docs.append(Document(
                                page_content=content,
                                metadata={"source": filepath.name}
                            ))
                    except Exception as err:
                        logger.warning(f"Failed to read doc file {filepath}: {err}")

        except Exception as e:
            logger.error(f"Error loading knowledge base documents: {e}")

        return docs

    def _build_faiss_fallback(self) -> Any:
        """Fallback to FAISS vector store if ChromaDB is unavailable."""
        try:
            from langchain_community.vectorstores import FAISS
            documents = self._load_documents()
            if not documents:
                documents = [Document(page_content="Python Documentation", metadata={"source": "default"})]
                
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=100)
            chunks = text_splitter.split_documents(documents)
            self.vector_store = FAISS.from_documents(chunks, self.embeddings)
            logger.info("Successfully built FAISS vector store fallback.")
            return self.vector_store
        except Exception as e:
            logger.error(f"FAISS fallback also failed: {e}")
            return None
