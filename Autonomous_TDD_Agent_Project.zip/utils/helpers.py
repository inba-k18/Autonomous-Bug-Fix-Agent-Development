import difflib
from typing import List, Dict, Any, Tuple
from pathlib import Path
from utils.logger import logger

def compute_code_diff(original_code: str, fixed_code: str) -> Dict[str, Any]:
    """
    Computes line-by-line diff between original code and fixed code.
    Returns structured stats and side-by-side formatted lines.
    """
    orig_lines = original_code.splitlines()
    fixed_lines = fixed_code.splitlines()
    
    matcher = difflib.SequenceMatcher(None, orig_lines, fixed_lines)
    diff_records = []
    
    added_count = 0
    removed_count = 0
    modified_count = 0
    
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            for o, f in zip(orig_lines[i1:i2], fixed_lines[j1:j2]):
                diff_records.append({
                    "type": "equal",
                    "orig_line_no": i1 + 1,
                    "orig": o,
                    "fixed_line_no": j1 + 1,
                    "fixed": f
                })
        elif tag == 'replace':
            max_len = max(i2 - i1, j2 - j1)
            modified_count += max_len
            for idx in range(max_len):
                o_no = i1 + idx + 1 if idx < (i2 - i1) else ""
                f_no = j1 + idx + 1 if idx < (j2 - j1) else ""
                o_val = orig_lines[i1 + idx] if idx < (i2 - i1) else ""
                f_val = fixed_lines[j1 + idx] if idx < (j2 - j1) else ""
                diff_records.append({
                    "type": "modified",
                    "orig_line_no": o_no,
                    "orig": o_val,
                    "fixed_line_no": f_no,
                    "fixed": f_val
                })
        elif tag == 'delete':
            removed_count += (i2 - i1)
            for idx in range(i2 - i1):
                diff_records.append({
                    "type": "removed",
                    "orig_line_no": i1 + idx + 1,
                    "orig": orig_lines[i1 + idx],
                    "fixed_line_no": "",
                    "fixed": ""
                })
        elif tag == 'insert':
            added_count += (j2 - j1)
            for idx in range(j2 - j1):
                diff_records.append({
                    "type": "added",
                    "orig_line_no": "",
                    "orig": "",
                    "fixed_line_no": j1 + idx + 1,
                    "fixed": fixed_lines[j1 + idx]
                })

    total_changes = added_count + removed_count + modified_count
    
    return {
        "stats": {
            "added": added_count,
            "removed": removed_count,
            "modified": modified_count,
            "total_changes": total_changes
        },
        "records": diff_records
    }

def clean_markdown_code_block(text: str) -> str:
    """Strips ```python and ``` block wrappers from LLM generated code."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines)
    return text.strip()

def save_file(filepath: Path, content: str) -> Path:
    """Safely write string content to specified file path."""
    try:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content, encoding="utf-8")
        logger.info(f"Successfully saved file to {filepath}")
        return filepath
    except Exception as e:
        logger.error(f"Failed to save file {filepath}: {str(e)}")
        raise e
